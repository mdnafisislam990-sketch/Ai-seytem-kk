package com.novaai.assistant.control

import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.telecom.TelecomManager
import android.telephony.SmsManager
import android.view.KeyEvent
import com.novaai.assistant.assist.VoiceSessionService
import com.novaai.assistant.data.Store
import com.novaai.assistant.utils.Perms
import com.novaai.assistant.voice.Tts
import kotlinx.coroutines.delay
import java.time.LocalTime
import java.time.format.DateTimeFormatter

data class ActResult(val reply: String, val quiet: Boolean = false, val close: Boolean = false)

/** Runs a Cmd on the phone. Quiet results are not spoken and not written to the chat. */
object Executor {
    private fun nm() = Store.name + " ভাই"
    private val NEED_A11Y = ActResult("অ্যাক্সেসিবিলিটিতে Nova AI চালু করো, তারপর আবার বলো")

    private fun launch(ctx: Context, i: Intent): Boolean =
        runCatching { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }.isSuccess

    private fun a11y(ctx: Context): NovaAccessibilityService? {
        val s = NovaAccessibilityService.instance
        if (s == null) launch(ctx, Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        return s
    }

    suspend fun run(ctx: Context, c: Cmd): ActResult = when (c) {
        is Cmd.OpenApp -> openApp(ctx, c.name)
        is Cmd.Call -> call(ctx, c.who)
        Cmd.Answer -> telecom(ctx, true)
        Cmd.HangUp -> telecom(ctx, false)
        is Cmd.Sms -> sms(ctx, c.who, c.text)
        is Cmd.WhatsApp -> whatsapp(ctx, c.who, c.text)
        is Cmd.Scroll -> {
            val a = a11y(ctx)
            if (a == null) NEED_A11Y else ActResult(if (c.next) "Next" else "Previous", quiet = a.swipeVertical(c.next))
        }
        is Cmd.AutoScroll -> {
            val a = a11y(ctx)
            if (a == null) NEED_A11Y else { a.startAuto(c.seconds); ActResult("ঠিক আছে, প্রতি ${c.seconds} সেকেন্ডে স্ক্রল করছি, ${nm()}. থামাতে বলো থামো") }
        }
        Cmd.StopScroll -> {
            Tts.stop()
            val was = NovaAccessibilityService.instance?.stopAuto() == true
            ActResult(if (was) "থামিয়ে দিলাম, ${nm()}" else "ঠিক আছে", quiet = !was)
        }
        is Cmd.Nav -> nav(ctx, c.kind)
        is Cmd.Tap -> {
            val a = a11y(ctx)
            if (a == null) NEED_A11Y else if (a.clickText(c.text)) ActResult("Tapped ${c.text}", quiet = true)
            else ActResult("${c.text} স্ক্রিনে দেখতে পাচ্ছি না")
        }
        is Cmd.Type -> {
            val a = a11y(ctx)
            if (a == null) NEED_A11Y else if (a.typeText(c.text)) ActResult("Typed", quiet = true)
            else ActResult("আগে লেখার ঘরে ট্যাপ করো, তারপর বলো")
        }
        Cmd.Like -> {
            val a = a11y(ctx)
            if (a == null) NEED_A11Y else ActResult("Liked", quiet = a.doubleTapCenter())
        }
        is Cmd.Volume -> volume(ctx, c.dir)
        is Cmd.Media -> media(ctx, c.kind)
        is Cmd.Torch -> torch(ctx, c.on)
        is Cmd.Panel -> panel(ctx, c.kind)
        Cmd.Time -> ActResult("এখন সময় " + LocalTime.now().format(DateTimeFormatter.ofPattern("h:mm a")) + ", ${nm()}")
        Cmd.StopMic -> {
            Handler(Looper.getMainLooper()).postDelayed({ VoiceSessionService.stop(ctx) }, 1500)
            ActResult("মাইক বন্ধ করলাম, ${nm()}")
        }
    }

    // ---------- apps ----------
    private val aliases = mapOf(
        "ফেসবুক" to "facebook", "ফেইসবুক" to "facebook", "হোয়াটসঅ্যাপ" to "whatsapp", "হোয়াটস অ্যাপ" to "whatsapp",
        "টিকটক" to "tiktok", "টিক টক" to "tiktok", "ইনস্টাগ্রাম" to "instagram", "মেসেঞ্জার" to "messenger",
        "টেলিগ্রাম" to "telegram", "ক্যামেরা" to "camera", "সেটিংস" to "settings", "ক্রোম" to "chrome",
        "গ্যালারি" to "gallery", "ইউটিউব" to "youtube", "জিমেইল" to "gmail", "ম্যাপ" to "maps"
    )

    private fun openApp(ctx: Context, raw: String): ActResult {
        val key = raw.trim().lowercase()
        val name = aliases[key] ?: key
        if (name == "youtube") { DeviceActions.openYouTube(ctx); return ActResult("ইউটিউব ওপেন করছি, ${nm()}") }
        if (name == "maps") { DeviceActions.openMaps(ctx); return ActResult("ম্যাপ ওপেন করছি, ${nm()}") }
        return if (DeviceActions.openAppByName(ctx, name)) ActResult("${raw.trim()} ওপেন করছি, ${nm()}")
        else ActResult("${raw.trim()} নামে কোনো অ্যাপ পাইনি, ${nm()}")
    }

    // ---------- navigation ----------
    private fun nav(ctx: Context, kind: String): ActResult {
        val a = a11y(ctx) ?: return NEED_A11Y
        val act: Int = when (kind) {
            "back" -> AccessibilityService.GLOBAL_ACTION_BACK
            "home" -> AccessibilityService.GLOBAL_ACTION_HOME
            "recents" -> AccessibilityService.GLOBAL_ACTION_RECENTS
            "notifications" -> AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS
            "quick" -> AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS
            "lock" -> if (Build.VERSION.SDK_INT >= 28) AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN else return ActResult("Lock screen needs Android 9 or newer")
            "screenshot" -> if (Build.VERSION.SDK_INT >= 28) AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT else return ActResult("Screenshot needs Android 9 or newer")
            else -> return ActResult("I don't know that button")
        }
        return ActResult(kind, quiet = a.global(act))
    }

    // ---------- calls & messages ----------
    private suspend fun resolve(ctx: Context, who: String): Pair<String?, ActResult?> {
        val isNum = who.any { it.isDigit() } && who.filter { !it.isDigit() && it != '+' && it != ' ' && it != '-' }.isEmpty()
        if (!isNum && !Contacts.canRead(ctx))
            return null to ActResult("কন্টাক্টের অনুমতি দাও: সেটিংস, ফোন কন্ট্রোল")
        val n = Contacts.numberFor(ctx, who)
        return if (n == null) null to ActResult("$who কে কন্টাক্টে পাইনি, ${nm()}") else n to null
    }

    private suspend fun call(ctx: Context, who: String): ActResult {
        val (num, err) = resolve(ctx, who)
        if (num == null) return err ?: ActResult("No number")
        val uri = Uri.parse("tel:" + Uri.encode(num))
        val direct = Perms.has(ctx, Manifest.permission.CALL_PHONE)
        val ok = launch(ctx, Intent(if (direct) Intent.ACTION_CALL else Intent.ACTION_DIAL, uri))
        return if (ok) ActResult("$who কে কল করছি, ${nm()}") else ActResult("Couldn't start the call")
    }

    private fun telecom(ctx: Context, answer: Boolean): ActResult {
        if (!Perms.has(ctx, Manifest.permission.ANSWER_PHONE_CALLS))
            return ActResult("Allow phone calls for Nova: Settings → Phone control & safety")
        val tm = ctx.getSystemService(Context.TELECOM_SERVICE) as TelecomManager
        return try {
            if (answer) { tm.acceptRingingCall(); ActResult("কল ধরছি, ${nm()}") }
            else if (Build.VERSION.SDK_INT >= 28) { tm.endCall(); ActResult("কল কেটে দিলাম, ${nm()}") }
            else ActResult("Ending calls needs Android 9 or newer")
        } catch (e: SecurityException) {
            ActResult("Allow phone calls for Nova first")
        }
    }

    private suspend fun sms(ctx: Context, who: String, text: String): ActResult {
        val (num, err) = resolve(ctx, who)
        if (num == null) return err ?: ActResult("No number")
        if (Perms.has(ctx, Manifest.permission.SEND_SMS)) {
            val ok = runCatching {
                @Suppress("DEPRECATION")
                val sm = if (Build.VERSION.SDK_INT >= 31) ctx.getSystemService(SmsManager::class.java) else SmsManager.getDefault()
                sm.sendMultipartTextMessage(num, null, sm.divideMessage(text), null, null)
            }.isSuccess
            return if (ok) ActResult("$who কে মেসেজ পাঠিয়ে দিয়েছি, ${nm()}") else ActResult("Couldn't send the message")
        }
        // No SMS permission: open the message app with the text ready, then press send.
        val i = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(num))).putExtra("sms_body", text)
        if (!launch(ctx, i)) return ActResult("No messaging app found")
        val a = NovaAccessibilityService.instance ?: return ActResult("Message is ready. Allow SMS for Nova to send it by voice")
        delay(1800)
        repeat(3) { if (a.clickSend()) return ActResult("$who কে মেসেজ পাঠিয়ে দিয়েছি, ${nm()}"); delay(600) }
        return ActResult("Message is ready, tap send")
    }

    private suspend fun whatsapp(ctx: Context, who: String, text: String): ActResult {
        val (num, err) = resolve(ctx, who)
        if (num == null) return err ?: ActResult("No number")
        val cc = Store.str("cc", "880")
        val uri = Uri.parse("https://wa.me/" + Contacts.intl(num, cc) + "?text=" + Uri.encode(text))
        val pkgs = listOf("com.whatsapp", "com.whatsapp.w4b")
        val opened = pkgs.any { p -> launch(ctx, Intent(Intent.ACTION_VIEW, uri).setPackage(p)) }
        if (!opened) return ActResult("WhatsApp isn't installed")
        val a = NovaAccessibilityService.instance ?: return ActResult("Chat is open. Turn on Nova accessibility to send by voice")
        delay(2800)
        repeat(5) { if (a.clickSend()) return ActResult("$who কে হোয়াটসঅ্যাপে মেসেজ পাঠিয়ে দিয়েছি, ${nm()}"); delay(700) }
        return ActResult("Chat is open, tap send")
    }

    // ---------- sound, media, hardware ----------
    private fun volume(ctx: Context, dir: String): ActResult {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val d = when (dir) {
            "down" -> AudioManager.ADJUST_LOWER
            "mute" -> AudioManager.ADJUST_TOGGLE_MUTE
            else -> AudioManager.ADJUST_RAISE
        }
        repeat(if (dir == "mute") 1 else 2) { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, d, AudioManager.FLAG_SHOW_UI) }
        return ActResult("Volume $dir", quiet = true)
    }

    private fun media(ctx: Context, kind: String): ActResult {
        val code = when (kind) {
            "pause" -> KeyEvent.KEYCODE_MEDIA_PAUSE
            "next" -> KeyEvent.KEYCODE_MEDIA_NEXT
            "prev" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
            else -> KeyEvent.KEYCODE_MEDIA_PLAY
        }
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
        return ActResult(kind, quiet = true)
    }

    private fun torch(ctx: Context, on: Boolean): ActResult {
        val ok = runCatching {
            val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.first { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
            cm.setTorchMode(id, on)
        }.isSuccess
        return if (ok) ActResult(if (on) "Flashlight on" else "Flashlight off", quiet = true) else ActResult("This phone has no flashlight")
    }

    private fun panel(ctx: Context, kind: String): ActResult {
        val i = when (kind) {
            "wifi" -> if (Build.VERSION.SDK_INT >= 29) Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY) else Intent(Settings.ACTION_WIFI_SETTINGS)
            "bluetooth" -> Intent(Settings.ACTION_BLUETOOTH_SETTINGS)
            "airplane" -> Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS)
            else -> Intent(Settings.ACTION_SETTINGS)
        }
        return if (launch(ctx, i)) ActResult("সেটিংস খুলছি, ${nm()}") else ActResult("Couldn't open $kind")
    }
}
