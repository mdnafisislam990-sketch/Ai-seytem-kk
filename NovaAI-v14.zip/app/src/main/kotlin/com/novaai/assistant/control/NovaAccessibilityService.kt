package com.novaai.assistant.control

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.graphics.Bitmap
import android.os.Build
import android.os.Bundle
import android.view.Display
import java.io.ByteArrayOutputStream
import kotlin.coroutines.resume
import kotlinx.coroutines.suspendCancellableCoroutine
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * Lets Nova press, swipe, scroll and type on any screen (TikTok, WhatsApp, Settings...).
 * The user must switch it on once: Settings > Accessibility > Nova AI.
 */
class NovaAccessibilityService : AccessibilityService() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var autoJob: Job? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        autoJob?.cancel(); instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        autoJob?.cancel(); scope.cancel(); instance = null
        super.onDestroy()
    }

    // ---- global buttons ----
    fun global(action: Int): Boolean = performGlobalAction(action)

    // ---- gestures ----
    fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, ms: Long = 260): Boolean {
        val p = Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, ms)).build()
        return dispatchGesture(g, null, null)
    }

    /** next = true moves to the next video / scrolls the page down (finger moves up). */
    fun swipeVertical(next: Boolean): Boolean {
        val dm = resources.displayMetrics
        val x = dm.widthPixels / 2f
        val from = dm.heightPixels * (if (next) 0.78f else 0.28f)
        val to = dm.heightPixels * (if (next) 0.28f else 0.78f)
        return swipe(x, from, x, to, 260)
    }

    fun tap(x: Float, y: Float): Boolean {
        val p = Path().apply { moveTo(x, y) }
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 60)).build()
        return dispatchGesture(g, null, null)
    }

    fun doubleTapCenter(): Boolean {
        val dm = resources.displayMetrics
        val p = Path().apply { moveTo(dm.widthPixels / 2f, dm.heightPixels * 0.45f) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0, 50))
            .addStroke(GestureDescription.StrokeDescription(p, 150, 50))
            .build()
        return dispatchGesture(g, null, null)
    }

    // ---- auto scroll ----
    fun startAuto(seconds: Int) {
        autoJob?.cancel()
        autoJob = scope.launch {
            while (isActive) {
                delay(seconds * 1000L)
                swipeVertical(true)
            }
        }
    }

    fun stopAuto(): Boolean {
        val was = autoJob?.isActive == true
        autoJob?.cancel(); autoJob = null
        return was
    }

    // ---- screen content ----
    /** Taps the element with this text or description (case-insensitive, partial match). */
    fun clickText(text: String): Boolean {
        val q = text.trim()
        if (q.isEmpty()) return false
        val root = rootInActiveWindow ?: return false
        var hits: List<AccessibilityNodeInfo> = root.findAccessibilityNodeInfosByText(q)
        if (hits.isEmpty()) {
            val low = q.lowercase()
            val found = ArrayList<AccessibilityNodeInfo>()
            fun walk(n: AccessibilityNodeInfo?, d: Int) {
                if (n == null || d > 30 || found.size > 8) return
                val t = ((n.text ?: "").toString() + " " + (n.contentDescription ?: "")).lowercase()
                if (n.isVisibleToUser && t.contains(low)) found.add(n)
                for (i in 0 until n.childCount) walk(n.getChild(i), d + 1)
            }
            walk(root, 0)
            hits = found
        }
        hits = hits.filter { it.isVisibleToUser }.ifEmpty { hits }
        for (n in hits) {
            var cur: AccessibilityNodeInfo? = n
            var depth = 0
            while (cur != null && depth < 6) {
                if (cur.isClickable && cur.isEnabled && cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
                cur = cur.parent
                depth++
            }
        }
        val first = hits.firstOrNull() ?: return false
        val r = Rect()
        first.getBoundsInScreen(r)
        return if (r.isEmpty) false else tap(r.exactCenterX(), r.exactCenterY())
    }

    /** Tap a spot given as percent of the screen (0..100). */
    fun tapPercent(xp: Double, yp: Double): Boolean {
        val dm = resources.displayMetrics
        return tap((xp.coerceIn(0.0, 100.0) / 100.0 * dm.widthPixels).toFloat(), (yp.coerceIn(0.0, 100.0) / 100.0 * dm.heightPixels).toFloat())
    }

    /** dir = the way the finger moves: up (scrolls down / next video), down, left, right. */
    fun swipeDir(dir: String): Boolean {
        val dm = resources.displayMetrics
        val w = dm.widthPixels.toFloat()
        val h = dm.heightPixels.toFloat()
        return when (dir.lowercase()) {
            "up" -> swipe(w / 2, h * 0.75f, w / 2, h * 0.30f)
            "down" -> swipe(w / 2, h * 0.30f, w / 2, h * 0.75f)
            "left" -> swipe(w * 0.8f, h / 2, w * 0.2f, h / 2)
            "right" -> swipe(w * 0.2f, h / 2, w * 0.8f, h / 2)
            else -> false
        }
    }

    fun clickSend(): Boolean =
        listOf("Send", "send", "পাঠান", "পাঠাও", "SEND").any { clickText(it) }

    fun typeText(s: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val f = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: findEditable(root) ?: return false
        val cur = f.text?.toString().orEmpty()
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, cur + s)
        }
        return f.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    private fun findEditable(n: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (n.isEditable) return n
        for (i in 0 until n.childCount) {
            val c = n.getChild(i) ?: continue
            val hit = findEditable(c)
            if (hit != null) return hit
        }
        return null
    }

    /** Visible things on screen, each with its position as "@x,y" in percent of the screen. */
    fun readScreen(): String {
        val root = rootInActiveWindow ?: return ""
        val dm = resources.displayMetrics
        val sb = StringBuilder()
        val r = Rect()
        fun walk(n: AccessibilityNodeInfo?, d: Int) {
            if (n == null || sb.length > 4000 || d > 25) return
            if (n.isVisibleToUser) {
                var t = (n.text ?: n.contentDescription)?.toString()?.trim().orEmpty()
                if (t.isEmpty() && n.isClickable) t = "(icon)"
                if (t.isNotEmpty()) {
                    n.getBoundsInScreen(r)
                    val x = (r.centerX() * 100 / dm.widthPixels.coerceAtLeast(1)).coerceIn(0, 100)
                    val y = (r.centerY() * 100 / dm.heightPixels.coerceAtLeast(1)).coerceIn(0, 100)
                    sb.append(t.take(120)).append(if (n.isClickable) " [button]" else "").append(" @").append(x).append(',').append(y).append('\n')
                }
            }
            for (i in 0 until n.childCount) walk(n.getChild(i), d + 1)
        }
        walk(root, 0)
        return sb.toString().trim()
    }

    /** A small JPEG of the screen (Android 11+), or null. */
    suspend fun screenshotJpeg(): ByteArray? {
        if (Build.VERSION.SDK_INT < 30) return null
        return suspendCancellableCoroutine { cont ->
            try {
                takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : AccessibilityService.TakeScreenshotCallback {
                    override fun onSuccess(r: AccessibilityService.ScreenshotResult) {
                        val out = try {
                            val hw = Bitmap.wrapHardwareBuffer(r.hardwareBuffer, r.colorSpace)
                            val bmp = hw?.copy(Bitmap.Config.ARGB_8888, false)
                            r.hardwareBuffer.close()
                            bmp?.let { b ->
                                val w = 640
                                val h = (b.height * w / b.width.toFloat()).toInt()
                                val s = Bitmap.createScaledBitmap(b, w, h, true)
                                val bo = ByteArrayOutputStream()
                                s.compress(Bitmap.CompressFormat.JPEG, 70, bo)
                                bo.toByteArray()
                            }
                        } catch (e: Exception) { null }
                        if (cont.isActive) cont.resume(out)
                    }
                    override fun onFailure(errorCode: Int) { if (cont.isActive) cont.resume(null) }
                })
            } catch (e: Exception) { if (cont.isActive) cont.resume(null) }
        }
    }

    companion object {
        @Volatile var instance: NovaAccessibilityService? = null
        fun isOn(): Boolean = instance != null
    }
}
