package com.novaai.assistant.ui

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.novaai.assistant.assist.Session
import com.novaai.assistant.assist.VoiceSessionService
import kotlin.math.cos
import kotlin.math.sin

/** Full-screen "call" with Nova: glowing orb, status line, Mute / End / Minimize. */
@Composable
fun LiveScreen(onClose: () -> Unit) {
    val ctx = LocalContext.current
    val active by Session.active.collectAsState()
    val hearing by Session.hearing.collectAsState()
    val busy by Session.busy.collectAsState()
    val speaking by Session.speaking.collectAsState()
    val info by Session.info.collectAsState()
    val muted by Session.muted.collectAsState()
    val t = rememberInfiniteTransition(label = "orb")
    val ph by t.animateFloat(0f, 1f, infiniteRepeatable(tween(14000, easing = LinearEasing)), label = "ph")
    val pulse by t.animateFloat(0f, 1f, infiniteRepeatable(tween(1100, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "pu")
    val amp = when { muted -> 0f; speaking -> 0.9f; hearing -> 1f; busy -> 0.6f; else -> 0.25f }
    val status = when {
        !active -> "Starting…"
        muted -> "Muted"
        busy -> "Nova is thinking…"
        speaking -> "Nova is speaking…"
        hearing -> "I’m listening…"
        else -> "Say a command…"
    }
    val stars = remember { val r = kotlin.random.Random(7); List(60) { Triple(r.nextFloat(), r.nextFloat(), r.nextFloat()) } }

    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF2A1650), Color(0xFF07040F))))) {
        Canvas(Modifier.fillMaxSize()) {
            stars.forEach { (x, y, a) ->
                drawCircle(Color.White.copy(alpha = 0.15f + 0.35f * a), 1.5f + 2f * a, Offset(x * size.width, y * size.height))
            }
        }
        Text(
            "Nova", fontFamily = FontFamily.Serif, fontSize = 34.sp, color = Color.White,
            modifier = Modifier.align(Alignment.TopStart).statusBarsPadding().padding(start = 24.dp, top = 24.dp)
        )
        Canvas(Modifier.align(Alignment.Center).offset(y = (-60).dp).size(320.dp)) {
            val c = center
            val r = size.minDimension / 2.6f * (1f + 0.04f * amp * pulse)
            drawCircle(Brush.radialGradient(listOf(Color(0xAAFFB547), Color.Transparent), c, r * 1.5f), r * 1.5f, c)
            val path = Path().apply { addOval(Rect(c, r)) }
            clipPath(path) {
                drawCircle(
                    Brush.radialGradient(listOf(Color(0xFF6A3BD8), Color(0xFF2A1272)), c - Offset(r * 0.2f, r * 0.3f), r * 1.4f),
                    r, c
                )
                val ang = ph * 6.2832f
                for (k in 0 until 6) {
                    val a = ang * (if (k % 2 == 0) 1f else -1f) + k * 1.05f
                    val p = c + Offset(cos(a) * r * 0.55f, sin(a * 0.8f) * r * 0.55f)
                    val col = when (k % 3) { 0 -> Color(0xFFFFB347); 1 -> Color(0xFFFF7BC8); else -> Color(0xFFFFD27A) }
                    val br = r * (0.38f + 0.12f * amp * pulse)
                    drawCircle(Brush.radialGradient(listOf(col.copy(alpha = 0.85f), Color.Transparent), p, br), br, p)
                }
            }
            val h = c - Offset(r * 0.4f, r * 0.45f)
            drawCircle(Brush.radialGradient(listOf(Color(0xCCFFFFFF), Color.Transparent), h, r * 0.3f), r * 0.3f, h)
            drawCircle(Color(0x55FFC66B), r, c, style = Stroke(3f))
        }
        Column(
            Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(status, fontFamily = FontFamily.Serif, fontStyle = FontStyle.Italic, fontSize = 30.sp, color = Color.White)
            Spacer(Modifier.height(8.dp))
            Text(if (info.isNotBlank()) info else "Keeps listening if you leave this screen.", color = Color(0x99FFFFFF), fontSize = 14.sp)
            Spacer(Modifier.height(36.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(28.dp), verticalAlignment = Alignment.CenterVertically) {
                RoundBtn(if (muted) "🔇" else "🎙️", if (muted) "Unmute" else "Mute", 68.dp, Color(0xFF1B1840)) {
                    VoiceSessionService.setMuted(!muted)
                }
                RoundBtn("📞", "End", 84.dp, Color(0xFFEF6F7E)) { VoiceSessionService.stop(ctx); onClose() }
                RoundBtn("⌄", "Minimize", 68.dp, Color(0xFF1B1840)) { onClose() }
            }
        }
    }
}

@Composable
private fun RoundBtn(icon: String, label: String, size: Dp, color: Color, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier.size(size).clip(CircleShape).background(color).clickable(onClick = onClick),
            contentAlignment = Alignment.Center
        ) { Text(icon, fontSize = 26.sp) }
        Spacer(Modifier.height(6.dp))
        Text(label, color = Color(0xCCFFFFFF), fontSize = 14.sp)
    }
}
