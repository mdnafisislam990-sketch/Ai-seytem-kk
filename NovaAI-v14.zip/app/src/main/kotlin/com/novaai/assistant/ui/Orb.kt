package com.novaai.assistant.ui

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.math.cos
import kotlin.math.sin

/** The glowing planet orb (same look as the call screen). [amp] 0..1 = how lively it is. */
@Composable
fun GlowOrb(modifier: Modifier = Modifier, size: Dp = 230.dp, amp: Float = 0.3f) {
    val t = rememberInfiniteTransition(label = "glow-orb")
    val ph by t.animateFloat(0f, 1f, infiniteRepeatable(tween(14000, easing = LinearEasing)), label = "ph")
    val pulse by t.animateFloat(0f, 1f, infiniteRepeatable(tween(1300, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "pu")
    Canvas(modifier.size(size)) {
        val c = center
        val r = this.size.minDimension / 2.6f * (1f + 0.05f * amp * pulse)
        drawCircle(Brush.radialGradient(listOf(Color(0x88B06CFF), Color.Transparent), c, r * 1.7f), r * 1.7f, c)
        val path = Path().apply { addOval(Rect(c, r)) }
        clipPath(path) {
            drawCircle(Brush.radialGradient(listOf(Color(0xFF6A3BD8), Color(0xFF2A1272)), c - Offset(r * 0.2f, r * 0.3f), r * 1.4f), r, c)
            val ang = ph * 6.2832f
            for (k in 0 until 6) {
                val a = ang * (if (k % 2 == 0) 1f else -1f) + k * 1.05f
                val p = c + Offset(cos(a) * r * 0.55f, sin(a * 0.8f) * r * 0.55f)
                val col = when (k % 3) { 0 -> Color(0xFFE060FF); 1 -> Color(0xFF8B5CFF); else -> Color(0xFFFFB347) }
                val br = r * (0.38f + 0.12f * amp * pulse)
                drawCircle(Brush.radialGradient(listOf(col.copy(alpha = 0.8f), Color.Transparent), p, br), br, p)
            }
        }
        val h = c - Offset(r * 0.4f, r * 0.45f)
        drawCircle(Brush.radialGradient(listOf(Color(0xCCFFFFFF), Color.Transparent), h, r * 0.3f), r * 0.3f, h)
        drawCircle(Color(0x88B48CFF), r, c, style = Stroke(3f))
    }
}
