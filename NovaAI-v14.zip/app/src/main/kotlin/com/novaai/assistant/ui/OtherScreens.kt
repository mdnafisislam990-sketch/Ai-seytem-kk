package com.novaai.assistant.ui

import android.content.Intent
import android.net.Uri
import android.os.Build
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.novaai.assistant.data.Store
import com.novaai.assistant.utils.Links
import com.novaai.assistant.utils.openUrl
import com.novaai.assistant.utils.toast

@Composable
fun PlaceholderScreen(name: String) =
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text(name) }

@Composable
fun MemoryScreen() {
    var mem by remember { mutableStateOf(Store.str("memory")) }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Memory", fontSize = 22.sp)
        Text("Things Nova should remember about you. Saved on this phone and shared with your AI as context.",
            color = NovaColors.TextDim, fontSize = 12.sp, modifier = Modifier.padding(vertical = 8.dp))
        OutlinedTextField(mem, { mem = it; Store.put("memory", it) }, Modifier.fillMaxWidth().heightIn(min = 180.dp),
            placeholder = { Text("e.g. My name is Jubayed. I like cricket.") })
    }
}

@Composable
fun HelpFeedbackScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    var type by remember { mutableIntStateOf(0) }
    var text by remember { mutableStateOf("") }
    var contact by remember { mutableStateOf("") }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("←", fontSize = 22.sp) }
            Text("Help & Feedback", fontSize = 22.sp)
        }
        Text("Something not working, or an idea to make Nova better? Tell us. We read every message.", color = NovaColors.TextDim, fontSize = 13.sp)
        Text("WRITE TO US", color = NovaColors.TextDim, fontSize = 11.sp)
        NovaCard(Modifier.fillMaxWidth()) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("What is it about?")
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(NovaColors.Navy)) {
                    listOf("Problem", "Idea").forEachIndexed { i, l ->
                        Box(
                            Modifier.weight(1f).clip(RoundedCornerShape(12.dp))
                                .background(if (type == i) NovaColors.Cyan else NovaColors.Navy)
                                .clickable { type = i }.padding(10.dp),
                            contentAlignment = Alignment.Center
                        ) { Text(l, color = if (type == i) androidx.compose.ui.graphics.Color.Black else NovaColors.TextDim) }
                    }
                }
            }
        }
        OutlinedTextField(text, { text = it }, Modifier.fillMaxWidth().heightIn(min = 130.dp),
            placeholder = { Text("Describe what happened (at least 5 letters)") })
        OutlinedTextField(contact, { contact = it }, Modifier.fillMaxWidth(), singleLine = true,
            placeholder = { Text("Your e-mail or Telegram. If you want a reply.") })
        Text("Sent with it: app version, phone model and Android version. No chats, no personal data.", color = NovaColors.TextDim, fontSize = 12.sp)
        Button(modifier = Modifier.fillMaxWidth(), enabled = text.trim().length >= 5, onClick = {
            val body = (if (type == 0) "Problem" else "Idea") + "\n\n" + text.trim() + "\n\nContact: " + contact +
                "\n\nApp v5.9 | ${Build.MANUFACTURER} ${Build.MODEL} | Android ${Build.VERSION.RELEASE}"
            val i = Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:")).putExtra(Intent.EXTRA_EMAIL, arrayOf(Links.EMAIL))
                .putExtra(Intent.EXTRA_SUBJECT, "Nova feedback").putExtra(Intent.EXTRA_TEXT, body)
            runCatching { ctx.startActivity(i) }.onFailure { ctx.toast("No e-mail app found") }
        }) { Text("Send") }

        Text("OR CONTACT US DIRECTLY", color = NovaColors.TextDim, fontSize = 11.sp)
        NovaCard(Modifier.fillMaxWidth(), onClick = { ctx.openUrl("mailto:" + Links.EMAIL) }) {
            Column { Text("✉️  E-mail"); Text(Links.EMAIL, color = NovaColors.TextDim, fontSize = 12.sp) }
        }
        NovaCard(Modifier.fillMaxWidth(), onClick = { ctx.openUrl("https://t.me/" + Links.TELEGRAM_HANDLE) }) {
            Column { Text("✈️  Telegram channel · Support"); Text("@" + Links.TELEGRAM_HANDLE, color = NovaColors.TextDim, fontSize = 12.sp) }
        }
    }
}

@Composable
fun FollowScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("←", fontSize = 22.sp) }
            Text("Follow Nova", fontSize = 22.sp)
        }
        Text("Our official pages. Follow them to see updates and news first.", color = NovaColors.TextDim, fontSize = 13.sp)
        NovaCard(Modifier.fillMaxWidth(), onClick = { ctx.openUrl(Links.FACEBOOK) }) {
            Column { Text("📘  Facebook"); Text("Official Nova AI page", color = NovaColors.TextDim, fontSize = 12.sp) }
        }
        NovaCard(Modifier.fillMaxWidth(), onClick = { ctx.openUrl(Links.INSTAGRAM) }) {
            Column { Text("📸  Instagram"); Text("@novaai.official062", color = NovaColors.TextDim, fontSize = 12.sp) }
        }
        NovaCard(Modifier.fillMaxWidth(), onClick = { ctx.openUrl(Links.TIKTOK) }) {
            Column { Text("🎵  TikTok"); Text("@novaai.official062", color = NovaColors.TextDim, fontSize = 12.sp) }
        }
    }
}
