package com.novaai.assistant.ui

import android.Manifest
import android.content.Intent
import android.provider.Settings
import android.os.Build
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.novaai.assistant.ai.LlmClient
import com.novaai.assistant.assist.Session
import com.novaai.assistant.control.NovaAccessibilityService
import com.novaai.assistant.data.Repo
import com.novaai.assistant.data.Store
import com.novaai.assistant.utils.Links
import com.novaai.assistant.utils.Perms
import com.novaai.assistant.utils.openUrl
import com.novaai.assistant.utils.toast

private class SItem(
    val icon: String, val title: String, val sub: String = "", val badge: String? = null,
    val toggle: Boolean? = null, val onToggle: (Boolean) -> Unit = {}, val onClick: () -> Unit = {}
)

@Composable
fun SettingsScreen(onNav: (String) -> Unit, onKeys: () -> Unit, onHey: (Boolean) -> Unit, onNotif: (Boolean) -> Unit, onControl: () -> Unit) {
    val ctx = LocalContext.current
    val live by Session.active.collectAsState()
    var needWake by remember { mutableStateOf(Store.bool("need_wake")) }
    var muteNotif by remember { mutableStateOf(Store.bool("mute_notif")) }
    val notif by Store.notif.collectAsState()
    val chats by Repo.history.collectAsState()
    var name by remember { mutableStateOf(Store.name) }
    var editName by remember { mutableStateOf(false) }
    var lang by remember { mutableStateOf(Store.str("lang", "bn-BD")) }
    var showPersona by remember { mutableStateOf(false) }

    val ready = listOf(
        true,
        Perms.has(ctx, Manifest.permission.RECORD_AUDIO),
        Perms.overlay(ctx),
        Build.VERSION.SDK_INT < 33 || Perms.has(ctx, Manifest.permission.POST_NOTIFICATIONS)
    ).count { it }
    val connected = if (LlmClient.provider() != null) "Ready" else "Add key"

    val ai = listOf(
        SItem("🔑", "Connections", "Gemini and Groq keys", connected, onClick = onKeys),
        SItem("🌐", "Voice & language", "Voice language: " + (if (lang == "bn-BD") "Bangla" else "English") + " (tap to switch)",
            onClick = { lang = if (lang == "bn-BD") "en-US" else "bn-BD"; Store.put("lang", lang); ctx.toast("Voice language changed") }),
        SItem("🤖", "Personality", Store.str("persona", "Friendly"), onClick = { showPersona = true }),
        SItem("💬", "Chats & memory", "${chats.size} saved chats", onClick = { onNav("memory") })
    )
    val app = listOf(
        SItem("🎙️", "Always-on mic", "Manual switch: ON stays on, OFF turns it off. It never stops by itself.", toggle = live, onToggle = onHey),
        SItem("👋", "Say \"Nova\" first", "Only react when you start with Nova / Hey Nova (for noisy places)", toggle = needWake,
            onToggle = { needWake = it; Store.putBool("need_wake", it) }),
        SItem("🔕", "Silence mic beep", "Also mutes the notification sound while the mic is on", toggle = muteNotif,
            onToggle = { muteNotif = it; Store.putBool("mute_notif", it); ctx.toast("Applies next time the mic starts") }),
        SItem("🔔", "Nova notification", "Tap it anywhere to open the mini orb", toggle = notif, onToggle = onNotif),
        SItem("🔋", "Keep mic alive", "Set battery to Unrestricted so the phone never kills the mic",
            onClick = { runCatching { ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } }),
        SItem("🛡️", "Phone control", "Calls, SMS, contacts + Accessibility for tap and scroll",
            badge = if (NovaAccessibilityService.isOn()) "On" else "Setup", onClick = onControl),
        SItem("⌨️", "Voice keyboard", "Type or speak in any app", onClick = { ctx.toast("Voice keyboard is coming in a later version") })
    )
    val about = listOf(
        SItem("💾", "Data & backup", "Share a backup of your chats and tasks", onClick = {
            val send = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, Repo.exportJson())
            ctx.startActivity(Intent.createChooser(send, "Nova backup").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }),
        SItem("✈️", "Support & updates", "Telegram channel @" + Links.TELEGRAM_HANDLE, onClick = { ctx.openUrl("https://t.me/" + Links.TELEGRAM_HANDLE) }),
        SItem("💬", "Help & Feedback", "Report a problem or share an idea", onClick = { onNav("help") }),
        SItem("🌍", "Follow Nova", "Facebook · Instagram · TikTok", onClick = { onNav("follow") }),
        SItem("🔒", "Privacy & about", "Made by ${Links.CREATOR} · v5.9",
            onClick = { ctx.toast("Data stays on your phone. Only your messages go to your AI provider.") }),
        SItem("🚪", "Log out", "", onClick = { Store.clearAll(); Repo.load(); name = Store.name; ctx.toast("Data cleared") })
    )

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Settings", fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Text("Customize your AI experience", color = NovaColors.TextDim, fontSize = 14.sp)
        NovaCard(Modifier.fillMaxWidth(), onClick = { editName = true }) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(54.dp).clip(CircleShape).background(NovaGrad), contentAlignment = Alignment.Center) {
                    Text(name.take(1).uppercase(), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 22.sp)
                }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text("NOVA AI", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text("Hi $name · tap to change name", color = NovaColors.TextDim, fontSize = 12.sp)
                    Text("Setup $ready of 4 ready", color = if (ready == 4) NovaColors.Green else NovaColors.Orange, fontSize = 12.sp)
                }
                Text("›", fontSize = 24.sp, color = NovaColors.TextDim)
            }
        }
        Section("AI SETTINGS", "Configure your AI assistant", ai)
        Section("APP SETTINGS", "Appearance and behavior", app)
        Section("ABOUT", "App information and support", about)
        Spacer(Modifier.height(90.dp))
    }

    if (showPersona) PersonaDialog(onDismiss = { showPersona = false })

    if (editName) PromptDialog("Your name", "Name", name, onDismiss = { editName = false }) {
        Store.name = it; name = it; editName = false
    }
}

@Composable
private fun Section(title: String, sub: String, items: List<SItem>) {
    Row(Modifier.fillMaxWidth().padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 2.sp, modifier = Modifier.weight(1f))
        Text(sub, color = NovaColors.TextDim, fontSize = 11.sp)
    }
    val shape = RoundedCornerShape(22.dp)
    Column(Modifier.fillMaxWidth().clip(shape).background(NovaColors.Card).border(1.dp, NovaColors.Line, shape)) {
        items.forEachIndexed { idx, it ->
            Row(
                Modifier.fillMaxWidth().then(if (it.toggle == null) Modifier.clickable(onClick = it.onClick) else Modifier).padding(horizontal = 14.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(Modifier.size(42.dp).clip(RoundedCornerShape(13.dp)).background(NovaColors.Purple), contentAlignment = Alignment.Center) {
                    Text(it.icon, fontSize = 20.sp)
                }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(it.title, fontSize = 16.sp, fontWeight = FontWeight.Medium)
                    if (it.sub.isNotEmpty()) Text(it.sub, color = NovaColors.TextDim, fontSize = 12.sp)
                }
                it.badge?.let { b ->
                    Box(Modifier.clip(RoundedCornerShape(50)).background(NovaColors.Green.copy(alpha = 0.16f)).padding(horizontal = 12.dp, vertical = 6.dp)) {
                        Text(b, color = NovaColors.Green, fontSize = 12.sp)
                    }
                    Spacer(Modifier.width(6.dp))
                }
                if (it.toggle != null) Switch(checked = it.toggle, onCheckedChange = it.onToggle)
                else Text("›", fontSize = 22.sp, color = NovaColors.TextDim)
            }
            if (idx < items.lastIndex) Box(Modifier.fillMaxWidth().padding(horizontal = 14.dp).height(1.dp).background(NovaColors.Line))
        }
    }
}
